plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android { namespace = "com.example.isochd"; compileSdk = 35
 defaultConfig { applicationId = "com.example.isochd"; minSdk = 26; targetSdk = 28; versionCode = 16; versionName = "1.6-dev" }
 ndkVersion = "27.2.12479018"
 externalNativeBuild { cmake { path = file("src/main/cpp/CMakeLists.txt"); version = "3.22.1" } }
 defaultConfig { ndk { abiFilters += listOf("arm64-v8a") } }
 buildTypes { release { isMinifyEnabled = false } }
 compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
 kotlinOptions { jvmTarget = "17" }
}

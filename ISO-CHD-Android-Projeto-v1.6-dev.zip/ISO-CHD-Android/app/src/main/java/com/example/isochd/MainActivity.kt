package com.example.isochd

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.StatFs
import android.provider.DocumentsContract
import android.provider.OpenableColumns
import android.view.ViewGroup
import android.widget.*
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

/** Android Storage Access Framework front-end for a separately built Android/Bionic CHDMAN. */
class MainActivity : Activity() {
    private val selected = mutableListOf<Uri>()
    private var destination: Uri? = null
    private val worker = Executors.newSingleThreadExecutor()
    private val ui = Handler(Looper.getMainLooper())
    private val cancelled = AtomicBoolean(false)
    private var running = false
    private lateinit var status: TextView
    private lateinit var log: TextView
    private lateinit var progress: ProgressBar
    private lateinit var start: Button
    private lateinit var stop: Button
    private lateinit var pick: Button
    private lateinit var choose: Button
    private lateinit var mode: Spinner
    private val pickFilesRequest = 100
    private val pickFolderRequest = 101

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
        }
        root.addView(TextView(this).apply { text = "ISO ↔ CHD Converter v1.6"; textSize = 23f })
        root.addView(TextView(this).apply { text = "CHD v5 zlib/raw (DVD 2048 bytes/setor). Outros codecs e CHDs de CD não são suportados. Originais preservados." })
        if (!NativeChd.available) {
            root.addView(TextView(this).apply {
                text = "Motor nativo indisponível nesta instalação. Verifique se o APK contém a biblioteca ARM64."
                setTextColor(android.graphics.Color.rgb(170, 45, 25))
            })
        }
        mode = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                listOf("ISO → CHD (DVD)", "CHD → ISO (DVD)"))
        }
        root.addView(mode)
        pick = button(root, "Selecionar imagens") {
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                type = "*/*"; addCategory(Intent.CATEGORY_OPENABLE)
                putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
            }, pickFilesRequest)
        }
        choose = button(root, "Selecionar pasta de saída") {
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT_TREE), pickFolderRequest)
        }
        status = TextView(this).apply { text = "Nenhuma imagem selecionada" }
        root.addView(status)
        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100 }
        root.addView(progress, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        start = button(root, "Converter lote") { startBatch() }
        stop = button(root, "Cancelar lote") {
            cancelled.set(true)
            append("Cancelamento solicitado. A operação nativa atual terminará antes da interrupção do lote.")
        }
        stop.isEnabled = false
        log = TextView(this).apply { text = "Pronto.\n"; textSize = 13f }
        root.addView(ScrollView(this).apply { addView(log) },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
    }

    private fun button(parent: LinearLayout, title: String, action: () -> Unit): Button =
        Button(this).also { it.text = title; it.setOnClickListener { action() }; parent.addView(it) }

    @Deprecated("Legacy activity result; no additional AndroidX dependency")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data == null || running) return
        if (requestCode == pickFilesRequest) {
            selected.clear()
            data.clipData?.let { clip -> for (i in 0 until clip.itemCount) selected.add(clip.getItemAt(i).uri) }
            if (selected.isEmpty()) data.data?.let { selected.add(it) }
            selected.distinct().toList().also { selected.clear(); selected.addAll(it) }
            selected.forEach {
                try { contentResolver.takePersistableUriPermission(it, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
                catch (_: SecurityException) { /* Session grant remains usable. */ }
            }
        } else if (requestCode == pickFolderRequest) {
            destination = data.data
            destination?.let {
                try { contentResolver.takePersistableUriPermission(it,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION) }
                catch (_: SecurityException) { /* Session grant remains usable. */ }
            }
        }
        status.text = "${selected.size} imagem(ns) selecionada(s) · destino: ${if (destination == null) "não definido" else "selecionado"}"
    }

    private fun displayName(uri: Uri): String = contentResolver.query(uri,
        arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
        if (it.moveToFirst()) it.getString(0) else null
    } ?: "arquivo"

    private fun fileSize(uri: Uri): Long = contentResolver.query(uri,
        arrayOf(OpenableColumns.SIZE), null, null, null)?.use {
        if (it.moveToFirst() && !it.isNull(0)) it.getLong(0) else -1L
    } ?: -1L

    private fun append(message: String) = ui.post { log.append("\n$message") }
    private fun setRunning(value: Boolean) = ui.post {
        running = value; start.isEnabled = !value; pick.isEnabled = !value
        choose.isEnabled = !value; mode.isEnabled = !value; stop.isEnabled = value
    }

    private fun runNative(input: File, output: File, toChd: Boolean) {
        if (cancelled.get()) throw InterruptedException("Lote cancelado")
        val result = NativeChd.convert(input.absolutePath, output.absolutePath, toChd)
        if (result != 0) error("Falha na conversão nativa (código $result).")
    }

    private fun startBatch() {
        if (running) return
        val folder = destination ?: return toast("Escolha uma pasta de saída")
        if (selected.isEmpty()) return toast("Selecione ao menos uma imagem")
        if (!NativeChd.available || !NativeChd.conversionSupported()) {
            append("Motor CHD nativo indisponível.")
            return toast("Motor nativo indisponível")
        }
        val inputs = selected.toList()
        val toChd = mode.selectedItemPosition == 0
        cancelled.set(false)
        setRunning(true)
        progress.progress = 0
        log.text = "Iniciando ${inputs.size} arquivo(s)..."
        worker.execute {
            var completed = 0; var failed = 0; var skipped = 0
            try {
                val tree = DocumentsContract.buildDocumentUriUsingTree(folder,
                    DocumentsContract.getTreeDocumentId(folder))
                val existing = mutableSetOf<String>()
                contentResolver.query(DocumentsContract.buildChildDocumentsUriUsingTree(folder,
                    DocumentsContract.getTreeDocumentId(folder)),
                    arrayOf(DocumentsContract.Document.COLUMN_DISPLAY_NAME), null, null, null)?.use { cursor ->
                    while (cursor.moveToNext()) existing.add(cursor.getString(0).lowercase())
                }
                inputs.forEachIndexed { index, uri ->
                    if (cancelled.get()) return@forEachIndexed
                    var input: File? = null; var output: File? = null
                    val name = displayName(uri)
                    val suffix = if (toChd) ".iso" else ".chd"
                    val outputName = name.substringBeforeLast('.') + if (toChd) ".chd" else ".iso"
                    try {
                        if (!name.endsWith(suffix, ignoreCase = true)) {
                            skipped++; append("Ignorado: $name (esperado $suffix)")
                            return@forEachIndexed
                        }
                        if (outputName.lowercase() in existing) {
                            skipped++; append("Ignorado: $outputName já existe na pasta de saída")
                            return@forEachIndexed
                        }
                        val size = fileSize(uri)
                        val free = StatFs(cacheDir.absolutePath).availableBytes
                        if (size < 0) error("Tamanho desconhecido: não é possível garantir espaço temporário")
                        // Conservative upper bound for both temporary input and output.
                        if (size > (Long.MAX_VALUE - 268435456L) / 3L ||
                            free < size * 3L + 268435456L)
                            error("Espaço interno insuficiente; libere aproximadamente 3× o tamanho da imagem + 256 MiB")
                        val inputFile = File.createTempFile("chd_input_", suffix, cacheDir)
                        val outputFile = File.createTempFile("chd_output_", if (toChd) ".chd" else ".iso", cacheDir)
                        input = inputFile
                        output = outputFile
                        outputFile.delete() // chdman expects a non-existing output path.
                        append("Convertendo: $name")
                        contentResolver.openInputStream(uri)?.use { source ->
                            FileOutputStream(inputFile).use { sink ->
                                val buffer = ByteArray(1024 * 1024)
                                while (true) {
                                    if (cancelled.get()) throw InterruptedException("Cancelado")
                                    val read = source.read(buffer)
                                    if (read < 0) break
                                    sink.write(buffer, 0, read)
                                }
                            }
                        } ?: error("Não foi possível ler a imagem")
                        runNative(inputFile, outputFile, toChd)
                        if (!outputFile.isFile || outputFile.length() == 0L) error("Saída vazia")
                        if (toChd && !NativeChd.verify(outputFile.absolutePath)) error("Falha na verificação do CHD")
                        if (cancelled.get()) throw InterruptedException("Cancelado")
                        // Prevent accidental overwrite even when output name was already present.
                        if (outputName.lowercase() in existing) error("Nome de saída duplicado")
                        val target = DocumentsContract.createDocument(contentResolver, tree,
                            "application/octet-stream", outputName) ?: error("Não foi possível criar saída")
                        try {
                            contentResolver.openOutputStream(target, "w")?.use { sink ->
                                FileInputStream(outputFile).use { source ->
                                    val buffer = ByteArray(1024 * 1024)
                                    while (true) {
                                        if (cancelled.get()) throw InterruptedException("Cancelado")
                                        val read = source.read(buffer)
                                        if (read < 0) break
                                        sink.write(buffer, 0, read)
                                    }
                                }
                            } ?: error("Não foi possível gravar saída")
                        } catch (e: Exception) {
                            try { DocumentsContract.deleteDocument(contentResolver, target) }
                            catch (_: Exception) { append("Atenção: remova manualmente a saída incompleta: $outputName") }
                            throw e
                        }
                        existing.add(outputName.lowercase())
                        completed++; append("Concluído: $outputName")
                    } catch (e: InterruptedException) {
                        append("Cancelado: $name")
                        cancelled.set(true)
                    } catch (e: Exception) {
                        failed++; append("Falha em $name: ${e.message}")
                    } finally {
                        input?.delete(); output?.delete()
                        ui.post { progress.progress = ((index + 1) * 100 / inputs.size) }
                    }
                }
            } catch (e: Exception) { append("Erro ao acessar destino: ${e.message}") }
            finally {
                append("Fim: $completed concluído(s), $failed falha(s), $skipped ignorado(s)" +
                    if (cancelled.get()) " · cancelado" else "")
                setRunning(false)
            }
        }
    }

    private fun toast(text: String) { Toast.makeText(this, text, Toast.LENGTH_LONG).show() }
    override fun onDestroy() {
        cancelled.set(true)
        worker.shutdownNow()
        super.onDestroy()
    }
}

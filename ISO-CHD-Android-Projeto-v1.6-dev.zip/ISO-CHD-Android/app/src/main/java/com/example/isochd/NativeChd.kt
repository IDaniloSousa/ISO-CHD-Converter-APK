package com.example.isochd

/** JNI boundary. Native bridge for the experimental zlib/raw DVD CHD v5 codec. */
object NativeChd {
    val available: Boolean = try { System.loadLibrary("isochd"); true } catch (_: UnsatisfiedLinkError) { false }
    external fun conversionSupported(): Boolean
    external fun convert(inputPath: String, outputPath: String, isoToChd: Boolean): Int
    external fun verify(chdPath: String): Boolean
    external fun inspect(path: String): String
}

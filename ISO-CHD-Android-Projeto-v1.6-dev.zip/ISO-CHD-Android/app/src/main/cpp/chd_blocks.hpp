#pragma once
#include <cstdint>
#include <istream>
#include <ostream>
#include <string>
#include <vector>

namespace chdv5 {
// Uncompressed CHD v5 map entries are 32-bit BE hunk indices. This module
// serializes the map and padded hunks, but does not write a complete CHD.
struct BlockLayout {
 uint32_t hunkBytes = 0;
 uint64_t logicalBytes = 0;
 uint64_t hunkCount = 0;
 uint64_t mapOffset = 124;
 uint64_t dataOffset = 0;
};
bool planBlocks(uint64_t logicalBytes, uint32_t hunkBytes, BlockLayout& layout, std::string& error);
bool encodeUncompressedBlocks(std::istream& input, std::ostream& output,
                              const BlockLayout& layout, std::string& error);
bool decodeUncompressedBlocks(std::istream& input, std::ostream& output,
                              const BlockLayout& layout, std::string& error);
}

#include "chd_compressed_writer.hpp"
#include "chd_v5.hpp"
#include "chd_map_v5.hpp"
#include "chd_deflate.hpp"
#include "chd_map_bits.hpp"
#include <algorithm>
#include <array>
#include <cstring>
#include <limits>
#include <vector>
namespace chdv5 {
namespace {
uint32_t rol(uint32_t v, unsigned n) { return (v<<n)|(v>>(32-n)); }
class Sha1 {
 uint32_t h[5]={0x67452301,0xefcdab89,0x98badcfe,0x10325476,0xc3d2e1f0};
 std::array<uint8_t,64> buf{};
 uint64_t bytes=0;
 size_t used=0;
 void block(const uint8_t* p) {
  uint32_t w[80]{};
  for(int i=0;i<16;i++) w[i]=(uint32_t(p[i*4])<<24)|(uint32_t(p[i*4+1])<<16)|(uint32_t(p[i*4+2])<<8)|p[i*4+3];
  for(int i=16;i<80;i++) w[i]=rol(w[i-3]^w[i-8]^w[i-14]^w[i-16],1);
  uint32_t a=h[0],b=h[1],c=h[2],d=h[3],e=h[4];
  for(int i=0;i<80;i++) {
   uint32_t f,k;
   if(i<20){f=(b&c)|(~b&d);k=0x5a827999;}
   else if(i<40){f=b^c^d;k=0x6ed9eba1;}
   else if(i<60){f=(b&c)|(b&d)|(c&d);k=0x8f1bbcdc;}
   else {f=b^c^d;k=0xca62c1d6;}
   uint32_t t=rol(a,5)+f+e+k+w[i];e=d;d=c;c=rol(b,30);b=a;a=t;
  }
  h[0]+=a;h[1]+=b;h[2]+=c;h[3]+=d;h[4]+=e;
 }
public:
 void update(const uint8_t* data,size_t n) {
  bytes+=n;
  while(n) {size_t take=std::min(n,64-used);std::memcpy(buf.data()+used,data,take);used+=take;data+=take;n-=take;if(used==64){block(buf.data());used=0;}}
 }
 std::array<uint8_t,20> finish() {
  uint64_t bits=bytes*8;
  uint8_t pad=0x80;update(&pad,1);
  uint8_t zero=0;while(used!=56)update(&zero,1);
  uint8_t len[8];for(int i=0;i<8;i++)len[7-i]=uint8_t(bits>>(8*i));update(len,8);
  std::array<uint8_t,20> result{};
  for(int i=0;i<5;i++)for(int j=0;j<4;j++)result[i*4+j]=uint8_t(h[i]>>(24-8*j));
  return result;
 }
};
void put32(uint8_t* p,uint32_t x){for(int i=0;i<4;i++)p[i]=uint8_t(x>>(24-8*i));}
void put64(uint8_t* p,uint64_t x){for(int i=0;i<8;i++)p[i]=uint8_t(x>>(56-8*i));}
bool hashInput(std::istream& input,uint64_t size,std::array<uint8_t,20>& digest,std::string& err){
 input.clear();input.seekg(0);if(!input){err="ISO seek failed";return false;}
 Sha1 sha;std::array<uint8_t,65536> buf{};
 while(size){size_t take=static_cast<size_t>(std::min<uint64_t>(size,buf.size()));
  if(!input.read(reinterpret_cast<char*>(buf.data()),static_cast<std::streamsize>(take))){err="ISO changed while hashing";return false;}
  sha.update(buf.data(),take);size-=take;
 }
 digest=sha.finish();return true;
}
bool readAt(std::istream& in,uint64_t off,std::vector<uint8_t>& bytes,std::string& error){
 if(off>static_cast<uint64_t>(std::numeric_limits<std::streamoff>::max())){error="Offset overflow";return false;}
 in.clear();in.seekg(static_cast<std::streamoff>(off));
 if(!in.read(reinterpret_cast<char*>(bytes.data()),static_cast<std::streamsize>(bytes.size()))){error="Truncated CHD payload";return false;}
 return true;
}
}
bool writeCompressedChd(std::istream& iso,std::iostream& chd,uint32_t hunkBytes,int level,std::string& error){
 uint64_t logical=0;
 if(!validateDvdIso(iso,logical,error))return false;
 if(hunkBytes<2048||hunkBytes>16U*1024*1024||hunkBytes%2048||level<0||level>9){error="Invalid hunk size or compression level";return false;}
 uint64_t count=logical/hunkBytes+(logical%hunkBytes!=0);
 if(count>10000000){error="Too many hunks";return false;}
 std::array<uint8_t,20> rawSha{};
 if(!hashInput(iso,logical,rawSha,error))return false;
 Sha1 combined;combined.update(rawSha.data(),rawSha.size());auto overall=combined.finish();
 iso.clear();iso.seekg(0);
 chd.clear();chd.seekp(0);
 std::array<uint8_t,HEADER_SIZE> blank{};
 if(!chd.write(reinterpret_cast<const char*>(blank.data()),blank.size())){error="Header reservation failed";return false;}
 std::vector<V5MapEntry> entries;entries.reserve(static_cast<size_t>(count));
 std::vector<uint8_t> raw(hunkBytes),packed;
 uint64_t remaining=logical,offset=HEADER_SIZE;
 for(uint64_t i=0;i<count;i++){
  std::fill(raw.begin(),raw.end(),0);
  size_t take=static_cast<size_t>(std::min<uint64_t>(remaining,hunkBytes));
  if(!iso.read(reinterpret_cast<char*>(raw.data()),static_cast<std::streamsize>(take))){error="ISO truncated";return false;}
  if(!deflateHunk(raw,packed,level,error))return false;
  bool compressed=packed.size()<raw.size();const auto& stored=compressed?packed:raw;
  if(stored.size()>0xffffff||offset>0xffffffffffffULL-stored.size()){error="CHD offset or length overflow";return false;}
  if(!chd.write(reinterpret_cast<const char*>(stored.data()),static_cast<std::streamsize>(stored.size()))){error="Hunk write failed";return false;}
  entries.push_back({static_cast<uint8_t>(compressed?0:4),static_cast<uint32_t>(stored.size()),offset,mapCrc16(raw.data(),raw.size())});
  offset+=stored.size();remaining-=take;
 }
 std::vector<uint8_t> map;
 if(!encodeV5Map(entries,hunkBytes,map,error))return false;
 if(!chd.write(reinterpret_cast<const char*>(map.data()),static_cast<std::streamsize>(map.size()))){error="Map write failed";return false;}
 std::array<uint8_t,HEADER_SIZE> header{};
 std::memcpy(header.data(),"MComprHD",8);put32(header.data()+8,HEADER_SIZE);put32(header.data()+12,5);
 // CHD v5 codec tag 'zlib' (not the host zlib wrapper format).
 put32(header.data()+16,0x7a6c6962);put64(header.data()+32,logical);put64(header.data()+40,offset);
 put32(header.data()+56,hunkBytes);put32(header.data()+60,2048);
 std::copy(rawSha.begin(),rawSha.end(),header.begin()+64);
 std::copy(overall.begin(),overall.end(),header.begin()+84);
 chd.clear();chd.seekp(0);
 if(!chd.write(reinterpret_cast<const char*>(header.data()),header.size())){error="Header write failed";return false;}
 chd.flush();if(!chd){error="Flush failed";return false;}
 return true;
}
bool verifyCompressedChd(std::istream& chd,std::string& error){
 Header h;if(!parseHeader(chd,h,error))return false;
 if(h.compressors[0]!=0x7a6c6962||h.compressors[1]||h.compressors[2]||h.compressors[3]||h.metaOffset||h.unitBytes!=2048||h.hunkBytes>16U*1024*1024){error="Unsupported CHD codec or layout";return false;}
 uint64_t count=h.logicalBytes/h.hunkBytes+(h.logicalBytes%h.hunkBytes!=0);
 if(count==0||count>10000000){error="Invalid hunk count";return false;}
 chd.clear();chd.seekg(0,std::ios::end);auto end=chd.tellg();
 if(end<0||static_cast<uint64_t>(end)<h.mapOffset+16){error="Map truncated";return false;}
 uint64_t mapSize=static_cast<uint64_t>(end)-h.mapOffset;
 if(mapSize>256ULL*1024*1024){error="Map too large";return false;}
 std::vector<uint8_t> map(static_cast<size_t>(mapSize));if(!readAt(chd,h.mapOffset,map,error))return false;
 std::vector<V5MapEntry> entries;if(!decodeV5Map(map,static_cast<size_t>(count),h.hunkBytes,entries,error))return false;
 Sha1 sha;uint64_t remain=h.logicalBytes;
 for(const auto& entry:entries){
  if(entry.offset<HEADER_SIZE||entry.offset>h.mapOffset||entry.length>h.mapOffset-entry.offset||entry.length>h.hunkBytes+65536U){error="Invalid hunk range";return false;}
  std::vector<uint8_t> stored(entry.length),raw;
  if(!readAt(chd,entry.offset,stored,error))return false;
  if(entry.type==0){if(!inflateHunk(stored,h.hunkBytes,raw,error))return false;}
  else if(entry.type==4){if(stored.size()!=h.hunkBytes){error="Invalid raw hunk";return false;}raw=std::move(stored);}
  else {error="Unsupported hunk codec";return false;}
  if(mapCrc16(raw.data(),raw.size())!=entry.crc){error="Hunk CRC mismatch";return false;}
  size_t take=static_cast<size_t>(std::min<uint64_t>(remain,h.hunkBytes));sha.update(raw.data(),take);remain-=take;
 }
 auto digest=sha.finish();if(digest!=h.rawSha1){error="Raw SHA-1 mismatch";return false;}
 Sha1 combined;combined.update(digest.data(),digest.size());if(combined.finish()!=h.sha1){error="Combined SHA-1 mismatch";return false;}
 return true;
}

bool extractCompressedChd(std::istream& chd, std::ostream& iso, std::string& error) {
 // Verify every hunk and SHA-1 before publishing extracted data.
 if (!verifyCompressedChd(chd,error)) return false;
 Header h;
 if (!parseHeader(chd,h,error)) return false;
 const uint64_t count=h.logicalBytes/h.hunkBytes+(h.logicalBytes%h.hunkBytes!=0);
 chd.clear();chd.seekg(0,std::ios::end);
 const auto end=chd.tellg();
 if(end<0 || static_cast<uint64_t>(end)<h.mapOffset){error="Invalid map offset";return false;}
 const uint64_t mapSize=static_cast<uint64_t>(end)-h.mapOffset;
 if(mapSize>256ULL*1024*1024){error="Map too large";return false;}
 std::vector<uint8_t> map(static_cast<size_t>(mapSize));
 if(!readAt(chd,h.mapOffset,map,error))return false;
 std::vector<V5MapEntry> entries;
 if(!decodeV5Map(map,static_cast<size_t>(count),h.hunkBytes,entries,error))return false;
 uint64_t remaining=h.logicalBytes;
 for(const auto& e:entries){
  if(e.offset<HEADER_SIZE||e.offset>h.mapOffset||e.length>h.mapOffset-e.offset){error="Hunk outside payload";return false;}
  std::vector<uint8_t> stored(e.length),raw;
  if(!readAt(chd,e.offset,stored,error))return false;
  if(e.type==0){if(!inflateHunk(stored,h.hunkBytes,raw,error))return false;}
  else if(e.type==4 && stored.size()==h.hunkBytes){raw=std::move(stored);}
  else {error="Unsupported hunk type";return false;}
  const size_t n=static_cast<size_t>(std::min<uint64_t>(remaining,h.hunkBytes));
  if(!iso.write(reinterpret_cast<const char*>(raw.data()),static_cast<std::streamsize>(n))){error="ISO write failed";return false;}
  remaining-=n;
 }
 iso.flush();if(!iso){error="ISO flush failed";return false;}
 return remaining==0;
}

}

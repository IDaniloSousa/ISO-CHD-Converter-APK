#pragma once
#include <cstdint>
#include <istream>
#include <ostream>
#include <string>
namespace chdv5 {
// Experimental CHD v5 zlib writer/validator. Not yet validated against MAME chdman.
bool writeCompressedChd(std::istream& iso, std::iostream& chd, uint32_t hunkBytes, int level, std::string& error);
bool verifyCompressedChd(std::istream& chd, std::string& error);
// Supports this project's zlib/raw DVD CHD v5 layout only.
bool extractCompressedChd(std::istream& chd, std::ostream& iso, std::string& error);
}

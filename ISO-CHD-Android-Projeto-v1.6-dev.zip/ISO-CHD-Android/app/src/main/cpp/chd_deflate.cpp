#include "chd_deflate.hpp"
#include <zlib.h>
#include <limits>
namespace chdv5 {
namespace {
constexpr size_t MAX_HUNK = 16U*1024*1024;
}
bool deflateHunk(const std::vector<uint8_t>& input, std::vector<uint8_t>& output,
                 int level, std::string& error) {
 output.clear();
 if(input.empty() || input.size()>MAX_HUNK || level<0 || level>9) {
  error="Invalid input hunk size or compression level"; return false;
 }
 z_stream z{};
 if(deflateInit2(&z,level,Z_DEFLATED,-MAX_WBITS,8,Z_DEFAULT_STRATEGY)!=Z_OK) {
  error="DEFLATE initialization failed"; return false;
 }
 output.resize(deflateBound(&z,static_cast<uLong>(input.size())));
 z.next_in=const_cast<Bytef*>(input.data()); z.avail_in=static_cast<uInt>(input.size());
 z.next_out=output.data(); z.avail_out=static_cast<uInt>(output.size());
 const int result=deflate(&z,Z_FINISH);
 const size_t written=z.total_out;
 deflateEnd(&z);
 if(result!=Z_STREAM_END) {output.clear();error="DEFLATE compression failed";return false;}
 output.resize(written);return true;
}
bool inflateHunk(const std::vector<uint8_t>& input, size_t expectedSize,
                 std::vector<uint8_t>& output, std::string& error) {
 output.clear();
 if(input.empty() || input.size()>MAX_HUNK+65536 || !expectedSize || expectedSize>MAX_HUNK) {
  error="Invalid compressed hunk or expected output size";return false;
 }
 z_stream z{};
 if(inflateInit2(&z,-MAX_WBITS)!=Z_OK) {error="DEFLATE decoder initialization failed";return false;}
 output.resize(expectedSize);
 z.next_in=const_cast<Bytef*>(input.data());z.avail_in=static_cast<uInt>(input.size());
 z.next_out=output.data();z.avail_out=static_cast<uInt>(output.size());
 const int result=inflate(&z,Z_FINISH);
 const bool ok=result==Z_STREAM_END && z.total_out==expectedSize && z.total_in==input.size();
 inflateEnd(&z);
 if(!ok){output.clear();error="Invalid, truncated, trailing, or size-mismatched DEFLATE hunk";return false;}
 return true;
}
}

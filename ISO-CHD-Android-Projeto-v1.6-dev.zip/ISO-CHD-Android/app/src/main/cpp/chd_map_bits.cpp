#include "chd_map_bits.hpp"
namespace chdv5 {
bool MapBitWriter::put(uint32_t value, unsigned width, std::string& error) {
 if (width > 32 || (width < 32 && width != 0 && (value >> width) != 0) || (width == 0 && value != 0)) {
  error = "Map bit-field width/value mismatch"; return false;
 }
 for (unsigned i = width; i > 0; --i) {
  if (bits_ % 8 == 0) bytes_.push_back(0);
  bytes_.back() |= static_cast<uint8_t>(((value >> (i - 1)) & 1u) << (7 - (bits_ % 8)));
  ++bits_;
 }
 return true;
}
bool MapBitReader::get(unsigned width, uint32_t& value, std::string& error) {
 if (width > 32 || width > bytes_.size() * 8 - bits_) {error="Map bitstream truncated or invalid width";return false;}
 value=0;
 for(unsigned i=0;i<width;++i){value=(value<<1)|((bytes_[bits_/8]>>(7-(bits_%8)))&1u);++bits_;}
 return true;
}
uint16_t mapCrc16(const uint8_t* data, size_t size) {
 uint16_t crc=0xffff;
 for(size_t i=0;i<size;++i){crc^=static_cast<uint16_t>(data[i])<<8;
  for(unsigned b=0;b<8;++b)crc=(crc&0x8000)?static_cast<uint16_t>((crc<<1)^0x1021):static_cast<uint16_t>(crc<<1);
 }
 return crc;
}
unsigned bitsNeeded(uint64_t value) {unsigned n=0;while(value){++n;value>>=1;}return n;}
}

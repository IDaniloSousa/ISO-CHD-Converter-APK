#pragma once
#include <cstdint>
#include <istream>
#include <ostream>
#include <string>
#include <vector>
namespace chdv5 {
// Internal staging format ONLY. Not the entropy-coded CHD v5 map.
struct StagedHunk { uint64_t offset; uint32_t storedBytes; uint32_t decodedBytes; uint16_t crc16; bool compressed; };
bool stageCompressedHunks(std::istream& source, std::ostream& payload,
                          uint64_t logicalBytes, uint32_t hunkBytes, int level,
                          std::vector<StagedHunk>& index, std::string& error);
bool restoreStagedHunks(std::istream& payload, std::ostream& destination,
                        const std::vector<StagedHunk>& index, std::string& error);
}

cmake_minimum_required(VERSION 3.22.1)
project(isochd LANGUAGES CXX)
add_library(isochd SHARED native_chd.cpp chd_v5.cpp chd_blocks.cpp chd_writer.cpp chd_deflate.cpp chd_compressed_stage.cpp chd_map_bits.cpp chd_map_huffman.cpp chd_map_v5.cpp
    chd_compressed_writer.cpp)
target_compile_features(isochd PRIVATE cxx_std_17)
target_compile_options(isochd PRIVATE -Wall -Wextra -Werror)

find_library(ANDROID_ZLIB z REQUIRED)
target_link_libraries(isochd PRIVATE ${ANDROID_ZLIB})

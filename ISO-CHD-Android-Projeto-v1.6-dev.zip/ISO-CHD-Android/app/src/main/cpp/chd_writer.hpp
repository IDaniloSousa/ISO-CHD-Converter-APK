#pragma once
#include "chd_v5.hpp"
#include "chd_blocks.hpp"
#include <array>
#include <istream>
#include <ostream>
#include <string>
namespace chdv5 {
// Produces a candidate uncompressed v5 image; official chdman compatibility unverified.
bool writeUncompressedChd(std::istream& iso, std::iostream& chd, uint32_t hunkBytes, std::string& error);
bool verifyUncompressedChd(std::istream& chd, std::string& error);
}

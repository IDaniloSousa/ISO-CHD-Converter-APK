#pragma once
#include <cstdint>
#include <string>
#include <vector>
namespace chdv5 {
// CHD v5 'zlib' codec payload: raw DEFLATE stream (negative zlib windowBits).
// This handles a single hunk only; a compressed CHD also needs the v5
// compressed hunk map, per-hunk checksums, and header compressor tags.
bool deflateHunk(const std::vector<uint8_t>& input, std::vector<uint8_t>& output,
                 int level, std::string& error);
bool inflateHunk(const std::vector<uint8_t>& input, size_t expectedSize,
                 std::vector<uint8_t>& output, std::string& error);
}

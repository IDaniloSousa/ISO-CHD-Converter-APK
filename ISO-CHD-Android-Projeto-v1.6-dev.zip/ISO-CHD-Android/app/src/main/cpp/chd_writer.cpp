#include "chd_writer.hpp"
#include <algorithm>
#include <array>
#include <cstring>
#include <limits>
#include <vector>
namespace chdv5 {
namespace {
uint32_t rol(uint32_t v, unsigned n) { return (v<<n)|(v>>(32-n)); }
class Sha1 {
 uint32_t h[5]={0x67452301,0xefcdab89,0x98badcfe,0x10325476,0xc3d2e1f0};
 std::array<uint8_t,64> buf{};
 uint64_t bytes=0;
 size_t used=0;
 void block(const uint8_t* p) {
  uint32_t w[80]{};
  for(int i=0;i<16;i++) w[i]=(uint32_t(p[i*4])<<24)|(uint32_t(p[i*4+1])<<16)|(uint32_t(p[i*4+2])<<8)|p[i*4+3];
  for(int i=16;i<80;i++) w[i]=rol(w[i-3]^w[i-8]^w[i-14]^w[i-16],1);
  uint32_t a=h[0],b=h[1],c=h[2],d=h[3],e=h[4];
  for(int i=0;i<80;i++) {
   uint32_t f,k;
   if(i<20){f=(b&c)|(~b&d);k=0x5a827999;}
   else if(i<40){f=b^c^d;k=0x6ed9eba1;}
   else if(i<60){f=(b&c)|(b&d)|(c&d);k=0x8f1bbcdc;}
   else {f=b^c^d;k=0xca62c1d6;}
   uint32_t t=rol(a,5)+f+e+k+w[i];e=d;d=c;c=rol(b,30);b=a;a=t;
  }
  h[0]+=a;h[1]+=b;h[2]+=c;h[3]+=d;h[4]+=e;
 }
public:
 void update(const uint8_t* data,size_t n) {
  bytes+=n;
  while(n) {size_t take=std::min(n,64-used);std::memcpy(buf.data()+used,data,take);used+=take;data+=take;n-=take;if(used==64){block(buf.data());used=0;}}
 }
 std::array<uint8_t,20> finish() {
  uint64_t bits=bytes*8;
  uint8_t pad=0x80;update(&pad,1);
  uint8_t zero=0;while(used!=56)update(&zero,1);
  uint8_t len[8];for(int i=0;i<8;i++)len[7-i]=uint8_t(bits>>(8*i));update(len,8);
  std::array<uint8_t,20> result{};
  for(int i=0;i<5;i++)for(int j=0;j<4;j++)result[i*4+j]=uint8_t(h[i]>>(24-8*j));
  return result;
 }
};
void put32(uint8_t* p,uint32_t x){for(int i=0;i<4;i++)p[i]=uint8_t(x>>(24-8*i));}
void put64(uint8_t* p,uint64_t x){for(int i=0;i<8;i++)p[i]=uint8_t(x>>(56-8*i));}
bool hashInput(std::istream& input,uint64_t size,std::array<uint8_t,20>& digest,std::string& err){
 input.clear();input.seekg(0);if(!input){err="ISO seek failed";return false;}
 Sha1 sha;std::array<uint8_t,65536> buf{};
 while(size){size_t take=static_cast<size_t>(std::min<uint64_t>(size,buf.size()));
  if(!input.read(reinterpret_cast<char*>(buf.data()),static_cast<std::streamsize>(take))){err="ISO changed while hashing";return false;}
  sha.update(buf.data(),take);size-=take;
 }
 digest=sha.finish();return true;
}
}
bool writeUncompressedChd(std::istream& iso,std::iostream& chd,uint32_t hunkBytes,std::string& err){
 uint64_t size=0;if(!validateDvdIso(iso,size,err))return false;
 BlockLayout l;if(!planBlocks(size,hunkBytes,l,err))return false;
 std::array<uint8_t,20> raw{};if(!hashInput(iso,size,raw,err))return false;
 // With no metadata, the overall SHA-1 hashes the 20 raw SHA-1 bytes.
 Sha1 overall;overall.update(raw.data(),raw.size());const auto combined=overall.finish();
 if(!encodeUncompressedBlocks(iso,chd,l,err))return false;
 std::array<uint8_t,HEADER_SIZE> header{};
 std::memcpy(header.data(),"MComprHD",8);
 put32(header.data()+8,HEADER_SIZE);put32(header.data()+12,5);
 // Four zero compression tags specify the v5 uncompressed-map variant.
 put64(header.data()+32,size);put64(header.data()+40,l.mapOffset);
 put64(header.data()+48,0);put32(header.data()+56,hunkBytes);put32(header.data()+60,2048);
 std::copy(raw.begin(),raw.end(),header.begin()+64);
 std::copy(combined.begin(),combined.end(),header.begin()+84);
 chd.clear();chd.seekp(0);
 if(!chd.write(reinterpret_cast<const char*>(header.data()),header.size())){err="Header write failed";return false;}
 chd.flush();if(!chd){err="Output flush failed";return false;}
 return true;
}
bool verifyUncompressedChd(std::istream& chd,std::string& err){
 Header h;if(!parseHeader(chd,h,err))return false;
 if(std::any_of(h.compressors.begin(),h.compressors.end(),[](uint32_t c){return c!=0;})) {err="Compressed CHD unsupported";return false;}
 BlockLayout l;if(!planBlocks(h.logicalBytes,h.hunkBytes,l,err))return false;
 if(h.mapOffset!=l.mapOffset||h.unitBytes!=2048||h.metaOffset!=0){err="Unsupported map or metadata layout";return false;}
 Sha1 sha;std::vector<uint8_t> buf(h.hunkBytes);
 uint64_t remain=h.logicalBytes;
 for(uint64_t i=0;i<l.hunkCount;i++){
  chd.clear();chd.seekg(static_cast<std::streamoff>(l.mapOffset+i*4));
  uint8_t index[4];if(!chd.read(reinterpret_cast<char*>(index),4)){err="Map truncated";return false;}
  uint32_t id=(uint32_t(index[0])<<24)|(uint32_t(index[1])<<16)|(uint32_t(index[2])<<8)|index[3];
  if(id>=l.hunkCount){err="Map index out of range";return false;}
  chd.clear();chd.seekg(static_cast<std::streamoff>(l.dataOffset+uint64_t(id)*l.hunkBytes));
  size_t n=static_cast<size_t>(std::min<uint64_t>(remain,h.hunkBytes));
  if(!chd.read(reinterpret_cast<char*>(buf.data()),static_cast<std::streamsize>(n))){err="Hunk truncated";return false;}
  sha.update(buf.data(),n);remain-=n;
 }
 auto raw=sha.finish();if(raw!=h.rawSha1){err="Raw SHA-1 mismatch";return false;}
 Sha1 combined;combined.update(raw.data(),raw.size());if(combined.finish()!=h.sha1){err="Combined SHA-1 mismatch";return false;}
 return true;
}
}

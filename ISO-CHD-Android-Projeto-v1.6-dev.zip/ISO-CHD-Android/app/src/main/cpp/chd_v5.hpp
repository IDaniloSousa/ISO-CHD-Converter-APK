#pragma once
#include <array>
#include <cstdint>
#include <istream>
#include <string>

namespace chdv5 {
constexpr uint32_t HEADER_SIZE = 124;
struct Header {
 uint32_t length = 0, version = 0;
 std::array<uint32_t,4> compressors{};
 uint64_t logicalBytes = 0, mapOffset = 0, metaOffset = 0;
 uint32_t hunkBytes = 0, unitBytes = 0;
 std::array<uint8_t,20> rawSha1{}, sha1{}, parentSha1{};
};
// Parses and validates header structure, NOT a full CHD integrity check.
bool parseHeader(std::istream& in, Header& out, std::string& error);
// Preflight only; never writes CHD data.
bool validateDvdIso(std::istream& in, uint64_t& size, std::string& error);
}

#pragma once
#include "chd_map_bits.hpp"
#include <array>
#include <cstdint>
#include <string>
#include <vector>
namespace chdv5 {
// Canonical Huffman primitive. The code-length table must be supplied by the caller.
// This is NOT the CHD v5 tree-length serialization format.
class CanonicalHuffman {
 public:
  bool init(const std::vector<uint8_t>& lengths, std::string& error);
  bool encode(MapBitWriter& out, uint16_t symbol, std::string& error) const;
  bool decode(MapBitReader& in, uint16_t& symbol, std::string& error) const;
 private:
  struct Code {uint32_t bits=0; uint8_t length=0;};
  std::vector<Code> codes_;
  unsigned max_length_=0;
};
// Internal RLE symbol stream: 0..15 literal types, 16 repeat preceding type.
// The repeat count is encoded as an unsigned 16-bit integer (2..65535).
// This representation is internal and is NOT the official CHD v5 RLE grammar.
bool encodeTypeStream(const std::vector<uint8_t>& types, const CanonicalHuffman& coder,
                      MapBitWriter& out, std::string& error);
bool decodeTypeStream(size_t count, const CanonicalHuffman& coder, MapBitReader& in,
                      std::vector<uint8_t>& types, std::string& error);
struct OffsetEntry {uint8_t type; uint64_t offset; uint32_t length;};
// Reconstruct sequential payload offsets for explicitly stored hunks.
// Types 0..3 are stored codecs; type 4 is raw/uncompressed; other types are references.
// Reference offsets require CHD-specific rules and are rejected here.
bool reconstructStoredOffsets(const std::vector<uint8_t>& types,
                              const std::vector<uint32_t>& lengths,
                              uint64_t first_offset, std::vector<OffsetEntry>& result,
                              std::string& error);
}

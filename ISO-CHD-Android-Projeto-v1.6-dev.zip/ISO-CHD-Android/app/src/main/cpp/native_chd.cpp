#include <jni.h>
#include <fstream>
#include <string>
#include <cstdio>
#include "chd_v5.hpp"
#include "chd_compressed_writer.hpp"

namespace {
std::string getPath(JNIEnv* env,jstring value) {
 if(!value)return {};
 const char* chars=env->GetStringUTFChars(value,nullptr);
 if(!chars)return {};
 std::string result(chars);
 env->ReleaseStringUTFChars(value,chars);
 return result;
}
}
extern "C" JNIEXPORT jboolean JNICALL
Java_com_example_isochd_NativeChd_conversionSupported(JNIEnv*, jobject){return JNI_TRUE;}
extern "C" JNIEXPORT jint JNICALL
Java_com_example_isochd_NativeChd_convert(JNIEnv* env,jobject,jstring source,jstring target,jboolean toChd){
 const auto inPath=getPath(env,source),outPath=getPath(env,target);
 if(inPath.empty()||outPath.empty()||inPath==outPath)return -1;
 std::ifstream input(inPath,std::ios::binary);
 if(!input)return -2;
 // Android staging files are created privately by the caller.
 std::fstream output(outPath,std::ios::binary|std::ios::in|std::ios::out|std::ios::trunc);
 if(!output)return -3;
 std::string error;
 const bool ok=toChd?chdv5::writeCompressedChd(input,output,262144,6,error)
                    :chdv5::extractCompressedChd(input,output,error);
 output.close();input.close();
 if(!ok){std::remove(outPath.c_str());return -4;}
 if(toChd){std::ifstream check(outPath,std::ios::binary);
  if(!chdv5::verifyCompressedChd(check,error)){check.close();std::remove(outPath.c_str());return -5;}}
 return 0;
}
extern "C" JNIEXPORT jboolean JNICALL
Java_com_example_isochd_NativeChd_verify(JNIEnv* env,jobject,jstring path){
 std::ifstream in(getPath(env,path),std::ios::binary);std::string err;
 return in&&chdv5::verifyCompressedChd(in,err)?JNI_TRUE:JNI_FALSE;
}
extern "C" JNIEXPORT jstring JNICALL
Java_com_example_isochd_NativeChd_inspect(JNIEnv* env,jobject,jstring path){
 std::ifstream f(getPath(env,path),std::ios::binary);
 if(!f)return env->NewStringUTF("Cannot open file");
 chdv5::Header h;std::string err;
 if(!chdv5::parseHeader(f,h,err))return env->NewStringUTF(err.c_str());
 std::string info="CHD v5 | logical bytes: "+std::to_string(h.logicalBytes)+" | hunk bytes: "+std::to_string(h.hunkBytes);
 return env->NewStringUTF(info.c_str());
}

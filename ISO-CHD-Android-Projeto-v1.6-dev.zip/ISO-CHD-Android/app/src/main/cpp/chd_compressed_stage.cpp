#include "chd_compressed_stage.hpp"
#include "chd_deflate.hpp"
#include <algorithm>
#include <limits>
namespace chdv5 {
namespace {
uint16_t crc16(const std::vector<uint8_t>& bytes) {
 uint16_t crc=0xffff;
 for(uint8_t b:bytes) { crc^=uint16_t(b)<<8; for(int k=0;k<8;k++) crc=(crc&0x8000)?uint16_t((crc<<1)^0x1021):uint16_t(crc<<1); }
 return crc;
}
}
bool stageCompressedHunks(std::istream& source,std::ostream& payload,uint64_t logicalBytes,
 uint32_t hunkBytes,int level,std::vector<StagedHunk>& index,std::string& error) {
 index.clear();
 if(!logicalBytes||!hunkBytes||hunkBytes>16U*1024*1024||level<0||level>9){error="Invalid staging parameters";return false;}
 const uint64_t count=logicalBytes/hunkBytes+(logicalBytes%hunkBytes!=0);
 if(count>10000000){error="Too many hunks";return false;}
 std::vector<uint8_t> raw(hunkBytes,0),compressed;
 uint64_t remaining=logicalBytes,offset=0;
 for(uint64_t i=0;i<count;i++) {
  std::fill(raw.begin(),raw.end(),0);
  const size_t take=static_cast<size_t>(std::min<uint64_t>(remaining,hunkBytes));
  if(!source.read(reinterpret_cast<char*>(raw.data()),static_cast<std::streamsize>(take))){error="Input truncated";return false;}
  if(!deflateHunk(raw,compressed,level,error))return false;
  const bool useCompressed=compressed.size()<raw.size();
  const auto& stored=useCompressed?compressed:raw;
  if(stored.size()>std::numeric_limits<uint32_t>::max()){error="Stored hunk too large";return false;}
  if(!payload.write(reinterpret_cast<const char*>(stored.data()),static_cast<std::streamsize>(stored.size()))){error="Payload write failed";return false;}
  index.push_back({offset,static_cast<uint32_t>(stored.size()),hunkBytes,crc16(raw),useCompressed});
  offset+=stored.size();remaining-=take;
 }
 return true;
}
bool restoreStagedHunks(std::istream& payload,std::ostream& destination,
 const std::vector<StagedHunk>& index,std::string& error) {
 uint64_t expectedOffset=0;
 for(const auto& entry:index) {
  if(entry.offset!=expectedOffset||!entry.storedBytes||!entry.decodedBytes||entry.decodedBytes>16U*1024*1024){error="Invalid staging index";return false;}
  std::vector<uint8_t> stored(entry.storedBytes),raw;
  if(!payload.read(reinterpret_cast<char*>(stored.data()),static_cast<std::streamsize>(stored.size()))){error="Payload truncated";return false;}
  if(entry.compressed){if(!inflateHunk(stored,entry.decodedBytes,raw,error))return false;}
  else {if(stored.size()!=entry.decodedBytes){error="Raw hunk length mismatch";return false;}raw=std::move(stored);}
  if(crc16(raw)!=entry.crc16){error="Hunk CRC-16 mismatch";return false;}
  if(!destination.write(reinterpret_cast<const char*>(raw.data()),static_cast<std::streamsize>(raw.size()))){error="Output write failed";return false;}
  expectedOffset+=entry.storedBytes;
 }
 return true;
}
}

#include "chd_map_v5.hpp"
#include "chd_map_bits.hpp"
#include "chd_map_huffman.hpp"
#include <algorithm>
#include <limits>
namespace chdv5 {
namespace {
void putbe(std::vector<uint8_t>& b,size_t pos,uint64_t v,size_t n){for(size_t i=0;i<n;i++)b[pos+i]=static_cast<uint8_t>(v>>(8*(n-i-1)));}
uint64_t getbe(const std::vector<uint8_t>& b,size_t pos,size_t n){uint64_t v=0;for(size_t i=0;i<n;i++)v=(v<<8)|b[pos+i];return v;}
bool treeWrite(MapBitWriter& w,const std::vector<uint8_t>& lens,std::string& e){
 for(size_t i=0;i<lens.size();){const unsigned v=lens[i];if(v>8){e="Invalid tree length";return false;}
 size_t j=i+1;while(j<lens.size()&&lens[j]==v)++j;size_t count=j-i;
 while(count){if(v==1){if(!w.put(1,4,e)||!w.put(1,4,e))return false;--count;}
 else if(count<=2){if(!w.put(v,4,e))return false;--count;}
 else {const auto extra=static_cast<uint32_t>(std::min<size_t>(count-3,15));
 if(!w.put(1,4,e)||!w.put(v,4,e)||!w.put(extra,4,e))return false;
 count-=extra+3;}}
 i=j;}return true;
}
bool treeRead(MapBitReader& r,std::vector<uint8_t>& lens,std::string& e){lens.clear();
 while(lens.size()<16){uint32_t v;if(!r.get(4,v,e))return false;
 if(v!=1){lens.push_back(static_cast<uint8_t>(v));continue;}
 uint32_t next;if(!r.get(4,next,e))return false;
 if(next==1){lens.push_back(1);continue;}
 uint32_t rep;if(!r.get(4,rep,e))return false;
 if(rep+3>16-lens.size()){e="Tree run exceeds alphabet";return false;}
 lens.insert(lens.end(),rep+3,static_cast<uint8_t>(next));}return true;
}
}
bool encodeV5Map(const std::vector<V5MapEntry>& entries,uint32_t hunkbytes,std::vector<uint8_t>& out,std::string& e){
 out.clear();if(entries.empty()||entries.size()>10000000||hunkbytes==0){e="Invalid hunk count or size";return false;}
 uint64_t first=entries.front().offset,off=first;uint32_t maxlen=0;
 if(first==0||first>0xffffffffffffULL){e="Invalid first offset";return false;}
 std::vector<uint8_t> raw(entries.size()*12,0);
 for(size_t i=0;i<entries.size();++i){auto x=entries[i];
 if(x.type>4||x.offset!=off||x.offset>0xffffffffffffULL){e="Unsupported type or non-contiguous payload";return false;}
 const uint32_t len=x.type==4?hunkbytes:x.length;
 if(!len||len>0xffffff||off>0xffffffffffffULL-len){e="Invalid stored length";return false;}
 if(x.type<4)maxlen=std::max(maxlen,len);
 raw[i*12]=x.type;putbe(raw,i*12+1,len,3);putbe(raw,i*12+4,off,6);putbe(raw,i*12+10,x.crc,2);off+=len;
 }
 unsigned lb=bitsNeeded(maxlen);if(lb>24){e="Invalid length width";return false;}
 // A complete 16-symbol, four-bit canonical tree is valid in MAME's RLE format.
 // All type symbols 0..4 are emitted literally; RLE tokens are optional.
 std::vector<uint8_t> lens(16,4);CanonicalHuffman coder;
 if(!coder.init(lens,e))return false;
 MapBitWriter w;if(!treeWrite(w,lens,e))return false;
 for(auto x:entries)if(!coder.encode(w,x.type,e))return false;
 for(auto x:entries){if(x.type<4&&!w.put(x.length,lb,e))return false;
 if(!w.put(x.crc,16,e))return false;}
 if(w.bytes().size()>UINT32_MAX){e="Map too large";return false;}
 out.resize(16,0);putbe(out,0,w.bytes().size(),4);putbe(out,4,first,6);
 putbe(out,10,mapCrc16(raw.data(),raw.size()),2);out[12]=static_cast<uint8_t>(lb);
 out.insert(out.end(),w.bytes().begin(),w.bytes().end());return true;
}
bool decodeV5Map(const std::vector<uint8_t>& input,size_t count,uint32_t hunkbytes,std::vector<V5MapEntry>& entries,std::string& e){
 entries.clear();if(input.size()<16||count==0||count>10000000||hunkbytes==0){e="Invalid map header";return false;}
 const auto bytes=getbe(input,0,4),first=getbe(input,4,6),crc=getbe(input,10,2);
 if(bytes!=input.size()-16||first==0||input[12]>24||input[13]!=0||input[14]!=0){e="Invalid map parameters";return false;}
 std::vector<uint8_t> payload(input.begin()+16,input.end());MapBitReader r(payload);
 std::vector<uint8_t> lens;if(!treeRead(r,lens,e))return false;
 CanonicalHuffman coder;if(!coder.init(lens,e))return false;
 std::vector<uint8_t> types;types.reserve(count);
 uint8_t last=0;size_t rep=0;
 for(size_t i=0;i<count;++i){if(rep){types.push_back(last);--rep;continue;}
 uint16_t s;if(!coder.decode(r,s,e))return false;
 if(s==7||s==8){uint16_t a,b=0;if(!coder.decode(r,a,e))return false;
 rep=s==7?size_t(2+a):size_t(18+(a<<4));
 if(s==8){if(!coder.decode(r,b,e))return false;rep+=b;}
 if(rep>=count-i){e="RLE exceeds hunk count";return false;}
 types.push_back(last);continue;}
 if(s>4){e="Reference types not yet supported";return false;}
 last=static_cast<uint8_t>(s);types.push_back(last);
 }
 uint64_t off=first;std::vector<uint8_t> raw(count*12,0);entries.reserve(count);
 for(size_t i=0;i<count;++i){uint32_t len=0,c=0;
 if(types[i]<4){if(!r.get(input[12],len,e))return false;}
 else len=hunkbytes;
 if(!r.get(16,c,e))return false;
 if(!len||len>0xffffff||off>0xffffffffffffULL-len){e="Invalid length or offset";return false;}
 entries.push_back({types[i],len,off,static_cast<uint16_t>(c)});
 raw[i*12]=types[i];putbe(raw,i*12+1,len,3);putbe(raw,i*12+4,off,6);putbe(raw,i*12+10,c,2);off+=len;
 }
 if(mapCrc16(raw.data(),raw.size())!=crc){e="Map CRC mismatch";entries.clear();return false;}
 return true;
}
}

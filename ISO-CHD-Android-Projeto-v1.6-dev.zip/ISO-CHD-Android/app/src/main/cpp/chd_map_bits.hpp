#pragma once
#include <cstddef>
#include <cstdint>
#include <string>
#include <vector>
namespace chdv5 {
// MSB-first bit stream primitives for the CHD v5 compressed map entropy coder.
// These are building blocks, NOT a complete CHD map encoder.
class MapBitWriter {
 public:
  bool put(uint32_t value, unsigned width, std::string& error);
  const std::vector<uint8_t>& bytes() const { return bytes_; }
  size_t bitCount() const { return bits_; }
 private:
  std::vector<uint8_t> bytes_;
  size_t bits_ = 0;
};
class MapBitReader {
 public:
  explicit MapBitReader(const std::vector<uint8_t>& bytes) : bytes_(bytes) {}
  bool get(unsigned width, uint32_t& value, std::string& error);
  size_t bitCount() const { return bits_; }
 private:
  const std::vector<uint8_t>& bytes_;
  size_t bits_ = 0;
};
uint16_t mapCrc16(const uint8_t* data, size_t size);
unsigned bitsNeeded(uint64_t value);
}

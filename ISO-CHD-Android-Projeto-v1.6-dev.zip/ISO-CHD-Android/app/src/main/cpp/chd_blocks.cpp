#include "chd_blocks.hpp"
#include <algorithm>
#include <array>
#include <limits>
#include <vector>

namespace chdv5 {
namespace {
void be32(uint8_t* p, uint32_t x) {
 p[0]=uint8_t(x>>24); p[1]=uint8_t(x>>16); p[2]=uint8_t(x>>8); p[3]=uint8_t(x);
}
uint32_t read32(const uint8_t* p) {
 return (uint32_t(p[0])<<24)|(uint32_t(p[1])<<16)|(uint32_t(p[2])<<8)|uint32_t(p[3]);
}
bool seekRead(std::istream& in, uint64_t pos) {
 if(pos>uint64_t(std::numeric_limits<std::streamoff>::max())) return false;
 in.clear(); in.seekg(static_cast<std::streamoff>(pos),std::ios::beg); return bool(in);
}
bool seekWrite(std::ostream& out, uint64_t pos) {
 if(pos>uint64_t(std::numeric_limits<std::streamoff>::max())) return false;
 out.clear(); out.seekp(static_cast<std::streamoff>(pos),std::ios::beg); return bool(out);
}
}
bool planBlocks(uint64_t size, uint32_t hunk, BlockLayout& l, std::string& error) {
 if(!size || !hunk || hunk%2048 || hunk>16U*1024*1024) {
  error="Invalid logical size or hunk size"; return false;
 }
 const uint64_t count=size/hunk+(size%hunk!=0);
 if(count>UINT32_MAX-1ULL) {error="Too many hunks for uncompressed map"; return false;}
 if(count>(UINT64_MAX-124)/4) {error="Map size overflow"; return false;}
 const uint64_t data=124+count*4;
 if(count>(UINT64_MAX-data)/hunk) {error="Data offset overflow"; return false;}
 l={hunk,size,count,124,data}; return true;
}
bool encodeUncompressedBlocks(std::istream& in,std::ostream& out,const BlockLayout& l,std::string& err) {
 BlockLayout expected;
 if(!planBlocks(l.logicalBytes,l.hunkBytes,expected,err) ||
    l.hunkCount!=expected.hunkCount || l.mapOffset!=expected.mapOffset ||
    l.dataOffset!=expected.dataOffset) {err="Inconsistent block layout"; return false;}
 if(!seekRead(in,0)) {err="Input seek failed"; return false;}
 // Reserve the 124-byte header region; the complete CHD writer will fill it.
 if(!seekWrite(out,0)) {err="Output seek failed"; return false;}
 std::array<char,124> reserved{};
 out.write(reserved.data(),static_cast<std::streamsize>(reserved.size()));
 if(!out || !seekWrite(out,l.mapOffset)) {err="Header reservation failed"; return false;}
 // Each uncompressed map entry is a BE index of the physical hunk.
 for(uint64_t i=0;i<l.hunkCount;++i) {
  uint8_t entry[4]; be32(entry,static_cast<uint32_t>(i));
  out.write(reinterpret_cast<const char*>(entry),4);
  if(!out) {err="Map write failed"; return false;}
 }
 std::vector<char> buffer(l.hunkBytes,0);
 uint64_t remaining=l.logicalBytes;
 for(uint64_t i=0;i<l.hunkCount;++i) {
  const auto take=static_cast<std::streamsize>(std::min<uint64_t>(remaining,l.hunkBytes));
  std::fill(buffer.begin(),buffer.end(),0);
  if(!in.read(buffer.data(),take)) {err="ISO truncated during block read"; return false;}
  out.write(buffer.data(),static_cast<std::streamsize>(buffer.size()));
  if(!out) {err="Hunk write failed"; return false;}
  remaining-=static_cast<uint64_t>(take);
 }
 return true;
}
bool decodeUncompressedBlocks(std::istream& in,std::ostream& out,const BlockLayout& l,std::string& err) {
 BlockLayout expected;
 if(!planBlocks(l.logicalBytes,l.hunkBytes,expected,err) ||
    l.hunkCount!=expected.hunkCount || l.mapOffset!=expected.mapOffset ||
    l.dataOffset!=expected.dataOffset) {err="Inconsistent block layout"; return false;}
 std::vector<char> buffer(l.hunkBytes);
 uint64_t remaining=l.logicalBytes;
 for(uint64_t i=0;i<l.hunkCount;++i) {
  if(!seekRead(in,l.mapOffset+i*4)) {err="Map seek failed"; return false;}
  uint8_t entry[4];
  if(!in.read(reinterpret_cast<char*>(entry),4)) {err="Map truncated"; return false;}
  const uint32_t index=read32(entry);
  if(index>=l.hunkCount) {err="Invalid map index"; return false;}
  if(!seekRead(in,l.dataOffset+uint64_t(index)*l.hunkBytes)) {err="Hunk seek failed"; return false;}
  const auto take=static_cast<std::streamsize>(std::min<uint64_t>(remaining,l.hunkBytes));
  if(!in.read(buffer.data(),take)) {err="Hunk truncated"; return false;}
  out.write(buffer.data(),take);
  if(!out) {err="Decoded output write failed"; return false;}
  remaining-=static_cast<uint64_t>(take);
 }
 return true;
}
}

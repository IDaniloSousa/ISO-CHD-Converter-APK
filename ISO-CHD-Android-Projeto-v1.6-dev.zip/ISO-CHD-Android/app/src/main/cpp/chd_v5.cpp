#include "chd_v5.hpp"
#include <algorithm>
#include <cstring>
#include <limits>

namespace chdv5 {
namespace {
uint32_t u32(const uint8_t* p) {return (uint32_t(p[0])<<24)|(uint32_t(p[1])<<16)|(uint32_t(p[2])<<8)|p[3];}
uint64_t u64(const uint8_t* p) {return (uint64_t(u32(p))<<32)|u32(p+4);}
}
bool parseHeader(std::istream& in, Header& h, std::string& err) {
 uint8_t b[HEADER_SIZE]{};
 in.clear(); in.seekg(0, std::ios::beg);
 if (!in.read(reinterpret_cast<char*>(b), sizeof(b))) {err="Truncated CHD v5 header"; return false;}
 if (std::memcmp(b,"MComprHD",8)!=0) {err="Invalid CHD magic"; return false;}
 h.length=u32(b+8); h.version=u32(b+12);
 if(h.version!=5 || h.length!=HEADER_SIZE) {err="Unsupported CHD header version or size"; return false;}
 for(int i=0;i<4;++i) h.compressors[i]=u32(b+16+i*4);
 h.logicalBytes=u64(b+32); h.mapOffset=u64(b+40); h.metaOffset=u64(b+48);
 h.hunkBytes=u32(b+56); h.unitBytes=u32(b+60);
 std::copy(b+64,b+84,h.rawSha1.begin());
 std::copy(b+84,b+104,h.sha1.begin());
 std::copy(b+104,b+124,h.parentSha1.begin());
 if(!h.logicalBytes || !h.hunkBytes || !h.unitBytes || h.hunkBytes%h.unitBytes!=0) {
  err="Invalid logical size, hunk size, or unit size"; return false;
 }
 if(h.hunkBytes>64*1024*1024U) {err="Unreasonable hunk size"; return false;}
 in.clear(); in.seekg(0,std::ios::end);
 const auto end=in.tellg();
 if(end<0) {err="Cannot determine file size"; return false;}
 const auto fileSize=static_cast<uint64_t>(end);
 if(h.mapOffset && (h.mapOffset<HEADER_SIZE || h.mapOffset>=fileSize)) {err="Map offset outside file"; return false;}
 if(h.metaOffset && (h.metaOffset<HEADER_SIZE || h.metaOffset>=fileSize)) {err="Metadata offset outside file"; return false;}
 return true;
}
bool validateDvdIso(std::istream& in,uint64_t& size,std::string& err) {
 in.clear(); in.seekg(0,std::ios::end);
 const auto end=in.tellg();
 if(end<0) {err="Cannot determine ISO size"; return false;}
 size=static_cast<uint64_t>(end);
 if(size==0 || size%2048!=0) {err="DVD ISO must be nonempty and 2048-byte sector aligned"; return false;}
 return true;
}
}

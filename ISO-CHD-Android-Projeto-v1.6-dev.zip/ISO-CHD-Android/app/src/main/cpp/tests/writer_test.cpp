#include "../chd_writer.hpp"
#include <cassert>
#include <sstream>
#include <string>
#include <iostream>
int main(){
 for(size_t size: {size_t(2048),size_t(4096),size_t(2048*17),size_t(2048*33)}){
  std::string original(size,'\0');for(size_t i=0;i<size;i++)original[i]=char(i*31+7);
  std::stringstream iso(original,std::ios::in|std::ios::out|std::ios::binary);
  std::stringstream chd(std::ios::in|std::ios::out|std::ios::binary);
  std::string err;assert(chdv5::writeUncompressedChd(iso,chd,8192,err));
  assert(chdv5::verifyUncompressedChd(chd,err));
  chdv5::BlockLayout l;assert(chdv5::planBlocks(size,8192,l,err));
  std::ostringstream recovered;assert(chdv5::decodeUncompressedBlocks(chd,recovered,l,err));
  assert(recovered.str()==original);
  chd.seekp(static_cast<std::streamoff>(l.dataOffset));chd.put('X');
  assert(!chdv5::verifyUncompressedChd(chd,err));
 }
 std::cout<<"Writer round trips and tamper tests passed\n";
}

#include "../chd_compressed_stage.hpp"
#include <cassert>
#include <sstream>
#include <vector>
#include <iostream>
int main(){
 for(size_t n:{size_t(1),size_t(4096),size_t(8192),size_t(10001),size_t(65536)}){
  std::string input(n,'A');for(size_t i=0;i<n;i+=37)input[i]=char(i%251);
  std::istringstream src(input,std::ios::binary);std::ostringstream payload(std::ios::binary);
  std::vector<chdv5::StagedHunk> entries;std::string error;
  assert(chdv5::stageCompressedHunks(src,payload,n,4096,6,entries,error));
  std::istringstream compressed(payload.str(),std::ios::binary);std::ostringstream restored(std::ios::binary);
  assert(chdv5::restoreStagedHunks(compressed,restored,entries,error));
  assert(restored.str().substr(0,n)==input);
  auto corrupted=entries;corrupted[0].crc16^=1;
  std::istringstream check(payload.str(),std::ios::binary);std::ostringstream discard(std::ios::binary);
  assert(!chdv5::restoreStagedHunks(check,discard,corrupted,error));
 }
 std::cout<<"5 staging round trips and CRC tamper checks passed\n";
}

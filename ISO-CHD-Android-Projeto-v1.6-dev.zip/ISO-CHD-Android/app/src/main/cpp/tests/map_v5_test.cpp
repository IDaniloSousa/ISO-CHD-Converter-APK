#include "../chd_map_v5.hpp"
#include <cassert>
#include <iostream>
int main(){using namespace chdv5;std::string err;std::vector<V5MapEntry> a;uint64_t off=124;
 for(int i=0;i<100;i++){uint8_t type=i%3==0?4:0;uint32_t len=type==4?4096:static_cast<uint32_t>(100+i);a.push_back({type,len,off,static_cast<uint16_t>(i*101)});off+=len;}
 std::vector<uint8_t> encoded;assert(encodeV5Map(a,4096,encoded,err));std::vector<V5MapEntry> decoded;
 if(!decodeV5Map(encoded,a.size(),4096,decoded,err)){std::cerr<<err<<'\n';return 1;}
 assert(decoded.size()==a.size());for(size_t i=0;i<a.size();i++){assert(a[i].type==decoded[i].type);assert(a[i].length==decoded[i].length);assert(a[i].offset==decoded[i].offset);assert(a[i].crc==decoded[i].crc);}
 encoded[10]^=1;assert(!decodeV5Map(encoded,a.size(),4096,decoded,err));
 std::cout<<"CHD v5 map: roundtrip and CRC rejection OK\n";}

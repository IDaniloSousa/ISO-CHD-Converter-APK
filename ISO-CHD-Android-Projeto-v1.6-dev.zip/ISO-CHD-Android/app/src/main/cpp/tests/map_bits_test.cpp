#include "../chd_map_bits.hpp"
#include <cassert>
#include <cstdint>
#include <iostream>
#include <vector>
int main(){
 using namespace chdv5;
 std::string error;MapBitWriter writer;
 assert(writer.put(5,3,error));assert(writer.put(0xabc,12,error));assert(writer.put(1,1,error));
 assert(writer.bytes()==std::vector<uint8_t>({0xb5,0x79}));
 MapBitReader reader(writer.bytes());uint32_t v=0;
 assert(reader.get(3,v,error)&&v==5);assert(reader.get(12,v,error)&&v==0xabc);
 assert(reader.get(1,v,error)&&v==1);assert(!reader.get(1,v,error));
 assert(!writer.put(8,3,error));assert(!writer.put(1,33,error));
 assert(bitsNeeded(0)==0&&bitsNeeded(1)==1&&bitsNeeded(255)==8&&bitsNeeded(256)==9);
 const uint8_t example[]={'1','2','3','4','5','6','7','8','9'};
 assert(mapCrc16(example,9)==0x29b1);
 std::cout<<"CHD map bitstream primitives: PASS\n";
}

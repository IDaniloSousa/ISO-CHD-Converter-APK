#include "../chd_deflate.hpp"
#include <cassert>
#include <cstdint>
#include <iostream>
#include <vector>
int main(){
 for(size_t size : {size_t(2048),size_t(4096),size_t(131072),size_t(1048576)}){
  for(int mode=0;mode<2;++mode){
   std::vector<uint8_t> source(size);
   uint32_t state=0x9e3779b9;
   for(auto& byte:source){state=state*1664525U+1013904223U;byte=mode?uint8_t(state>>24):uint8_t((state>>24)&3);}
   std::vector<uint8_t> compressed,decoded;std::string err;
   assert(chdv5::deflateHunk(source,compressed,6,err));
   assert(chdv5::inflateHunk(compressed,size,decoded,err));
   assert(decoded==source);
   assert(!chdv5::inflateHunk(compressed,size-1,decoded,err));
   auto corrupted=compressed;corrupted.pop_back();
   assert(!chdv5::inflateHunk(corrupted,size,decoded,err));
  }
 }
 std::cout<<"8 raw DEFLATE hunk round trips and rejection tests passed\n";
}

#include "../chd_map_huffman.hpp"
#include <cassert>
#include <iostream>
using namespace chdv5;
int main(){
 std::string error;CanonicalHuffman h;
 // 17-symbol fixed 5-bit canonical alphabet (includes repeat symbol 16).
 assert(h.init(std::vector<uint8_t>(17,5),error));
 std::vector<uint8_t> types={0,0,0,0,0,1,2,2,3,3,3,3,4,4,4,4,4,4,4};
 MapBitWriter writer;assert(encodeTypeStream(types,h,writer,error));
 MapBitReader reader(writer.bytes());std::vector<uint8_t> decoded;
 assert(decodeTypeStream(types.size(),h,reader,decoded,error));assert(decoded==types);
 std::vector<uint32_t> lengths(types.size(),4096);std::vector<OffsetEntry> offsets;
 assert(reconstructStoredOffsets(types,lengths,124,offsets,error));
 for(size_t i=0;i<offsets.size();++i)assert(offsets[i].offset==124+i*4096);
 CanonicalHuffman bad;assert(!bad.init({1,1,1},error));
 MapBitWriter truncated;assert(h.encode(truncated,16,error));
 MapBitReader invalid(truncated.bytes());std::vector<uint8_t> output;
 assert(!decodeTypeStream(2,h,invalid,output,error));
 assert(!reconstructStoredOffsets({5},{100},124,offsets,error));
 std::cout<<"Huffman, RLE, offsets: PASS\n";
}

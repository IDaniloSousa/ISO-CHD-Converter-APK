#include "../chd_compressed_writer.hpp"
#include <cassert>
#include <sstream>
#include <string>
#include <iostream>
int main(){
 for(size_t sectors: {size_t(1),size_t(8),size_t(33),size_t(128)}){
  std::string iso(sectors*2048,'\0');
  for(size_t i=0;i<iso.size();++i)iso[i]=char((i/17+i/4096)%251);
  std::stringstream src(iso,std::ios::in|std::ios::out|std::ios::binary);
  std::stringstream chd(std::ios::in|std::ios::out|std::ios::binary);
  std::string err;
  if(!chdv5::writeCompressedChd(src,chd,8192,6,err)){std::cerr<<err<<'\n';return 1;}
  if(!chdv5::verifyCompressedChd(chd,err)){std::cerr<<err<<'\n';return 2;}
  std::string corrupted=chd.str();corrupted[125]^=1;
  std::stringstream bad(corrupted,std::ios::in|std::ios::out|std::ios::binary);
  if(chdv5::verifyCompressedChd(bad,err)){std::cerr<<"Corruption undetected\n";return 3;}
 }
 std::cout<<"Compressed writer self-tests passed\n";
}

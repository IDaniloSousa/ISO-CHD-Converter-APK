#include "../chd_compressed_writer.hpp"
#include <sstream>
#include <iostream>
int main(){
 for(size_t sectors: {size_t(1),size_t(8),size_t(33),size_t(128),size_t(1024)}){
  std::string iso(sectors*2048,'\0');
  for(size_t i=0;i<iso.size();++i)iso[i]=char((i/17+i/4096)%251);
  std::stringstream src(iso,std::ios::in|std::ios::out|std::ios::binary);
  std::stringstream chd(std::ios::in|std::ios::out|std::ios::binary);
  std::stringstream extracted(std::ios::in|std::ios::out|std::ios::binary);
  std::string error;
  if(!chdv5::writeCompressedChd(src,chd,8192,6,error)){std::cerr<<error;return 1;}
  if(!chdv5::extractCompressedChd(chd,extracted,error)){std::cerr<<error;return 2;}
  if(extracted.str()!=iso){std::cerr<<"Mismatch";return 3;}
 }
 std::cout<<"Extract round-trip tests passed\n";
}

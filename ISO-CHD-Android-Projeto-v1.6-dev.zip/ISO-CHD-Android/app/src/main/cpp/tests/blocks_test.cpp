#include "../chd_blocks.hpp"
#include <cassert>
#include <sstream>
#include <string>
#include <iostream>
int main() {
 for(size_t n : {size_t(2048),size_t(4096),size_t(8192),size_t(10240),size_t(32768)}) {
  std::string original(n,'\0');
  for(size_t i=0;i<n;++i) original[i]=char((i*31+7)%256);
  std::istringstream source(original,std::ios::binary);
  std::ostringstream encoded(std::ios::binary);
  chdv5::BlockLayout layout; std::string err;
  assert(chdv5::planBlocks(n,8192,layout,err));
  assert(chdv5::encodeUncompressedBlocks(source,encoded,layout,err));
  const auto bytes=encoded.str();
  assert(bytes.size()==layout.dataOffset+layout.hunkCount*layout.hunkBytes);
  std::istringstream input(bytes,std::ios::binary);
  std::ostringstream decoded(std::ios::binary);
  assert(chdv5::decodeUncompressedBlocks(input,decoded,layout,err));
  assert(decoded.str()==original);
 }
 std::cout<<"Block map and padded-hunk round trips passed\n";
}

#include "../chd_v5.hpp"
#include <cassert>
#include <sstream>
#include <string>
#include <cstdint>

static void put32(std::string& s,size_t off,uint32_t n) {
 for(int i=3;i>=0;--i) {s[off+i]=static_cast<char>(n&255);n>>=8;}
}
static void put64(std::string& s,size_t off,uint64_t n) {
 put32(s,off,static_cast<uint32_t>(n>>32));put32(s,off+4,static_cast<uint32_t>(n));
}
int main() {
 std::string bytes(124,'\0'); bytes.replace(0,8,"MComprHD");
 put32(bytes,8,124);put32(bytes,12,5);put64(bytes,32,2048*20);
 put32(bytes,56,4096);put32(bytes,60,2048);
 chdv5::Header h;std::string error;
 std::istringstream good(bytes);
 assert(chdv5::parseHeader(good,h,error));
 assert(h.version==5 && h.logicalBytes==40960 && h.unitBytes==2048);
 bytes[0]='X';std::istringstream bad(bytes);
 assert(!chdv5::parseHeader(bad,h,error));
 std::istringstream iso(std::string(4096,'x'));
 uint64_t size=0;assert(chdv5::validateDvdIso(iso,size,error) && size==4096);
 std::istringstream badIso(std::string(3000,'x'));
 assert(!chdv5::validateDvdIso(badIso,size,error));
}

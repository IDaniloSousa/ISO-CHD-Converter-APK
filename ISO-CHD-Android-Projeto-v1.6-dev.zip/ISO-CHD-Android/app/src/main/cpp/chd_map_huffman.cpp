#include "chd_map_huffman.hpp"
#include <limits>
namespace chdv5 {
bool CanonicalHuffman::init(const std::vector<uint8_t>& lengths, std::string& error) {
 codes_.clear(); max_length_=0;
 if(lengths.empty() || lengths.size()>65536){error="Invalid alphabet size";return false;}
 std::array<uint32_t, 33> count{};
 for(auto len:lengths){if(len>32){error="Huffman length exceeds 32";return false;}if(len){++count[len];if(len>max_length_)max_length_=len;}}
 if(!max_length_){error="Empty Huffman tree";return false;}
 // Reject over-subscribed trees, including integer overflow.
 uint64_t available=1;
 for(unsigned len=1;len<=max_length_;++len){available=available*2;
  if(count[len]>available){error="Over-subscribed Huffman tree";return false;}
  available-=count[len];
 }
 std::array<uint32_t,33> next{};uint64_t code=0;
 for(unsigned len=1;len<=max_length_;++len){code=(code+count[len-1])*2;
  if(code>std::numeric_limits<uint32_t>::max()){error="Huffman code overflow";return false;}
  next[len]=static_cast<uint32_t>(code);
 }
 codes_.resize(lengths.size());
 for(size_t i=0;i<lengths.size();++i)if(lengths[i])codes_[i]={next[lengths[i]]++,lengths[i]};
 return true;
}
bool CanonicalHuffman::encode(MapBitWriter& out,uint16_t symbol,std::string& error) const {
 if(symbol>=codes_.size() || !codes_[symbol].length){error="Unknown Huffman symbol";return false;}
 const auto c=codes_[symbol];return out.put(c.bits,c.length,error);
}
bool CanonicalHuffman::decode(MapBitReader& in,uint16_t& symbol,std::string& error) const {
 uint32_t code=0;
 for(unsigned len=1;len<=max_length_;++len){uint32_t bit=0;if(!in.get(1,bit,error))return false;
  code=(code<<1)|bit;
  for(size_t i=0;i<codes_.size();++i)if(codes_[i].length==len && codes_[i].bits==code){symbol=static_cast<uint16_t>(i);return true;}
 }
 error="Invalid Huffman prefix";return false;
}
bool encodeTypeStream(const std::vector<uint8_t>& types,const CanonicalHuffman& coder,MapBitWriter& out,std::string& error){
 for(size_t i=0;i<types.size();){
  if(types[i]>15){error="Type outside 0..15";return false;}
  size_t run=1;while(i+run<types.size() && types[i+run]==types[i] && run<65535)++run;
  if(!coder.encode(out,types[i],error))return false;
  if(run>=3){if(!coder.encode(out,16,error) || !out.put(static_cast<uint32_t>(run-1),16,error))return false;i+=run;}
  else {++i;}
 }
 return true;
}
bool decodeTypeStream(size_t count,const CanonicalHuffman& coder,MapBitReader& in,std::vector<uint8_t>& types,std::string& error){
 types.clear();if(count>10000000){error="Excessive type count";return false;}
 while(types.size()<count){uint16_t symbol=0;if(!coder.decode(in,symbol,error))return false;
  if(symbol<16){types.push_back(static_cast<uint8_t>(symbol));continue;}
  if(symbol!=16 || types.empty()){error="Invalid repeat token";return false;}
  uint32_t repeat=0;if(!in.get(16,repeat,error))return false;
  if(repeat<2 || repeat>count-types.size()){error="Invalid repeat length";return false;}
  types.insert(types.end(),repeat,types.back());
 }
 return true;
}
bool reconstructStoredOffsets(const std::vector<uint8_t>& types,const std::vector<uint32_t>& lengths,uint64_t first_offset,std::vector<OffsetEntry>& result,std::string& error){
 result.clear();if(types.size()!=lengths.size()){error="Mismatched map vectors";return false;}
 uint64_t offset=first_offset;
 for(size_t i=0;i<types.size();++i){if(types[i]>4){error="Reference hunk not supported";return false;}
  if(lengths[i]==0 || offset>UINT64_MAX-lengths[i]){error="Invalid hunk length or offset overflow";return false;}
  result.push_back({types[i],offset,lengths[i]});offset+=lengths[i];
 }
 return true;
}
}

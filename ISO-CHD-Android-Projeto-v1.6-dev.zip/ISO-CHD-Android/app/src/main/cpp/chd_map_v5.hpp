#pragma once
#include <cstdint>
#include <string>
#include <vector>
namespace chdv5 {
// CHD v5 compressed-map serializer for stored hunks (types 0..4).
// References (types 5..6) and pseudo-types are not emitted by this writer.
struct V5MapEntry { uint8_t type; uint32_t length; uint64_t offset; uint16_t crc; };
bool encodeV5Map(const std::vector<V5MapEntry>& entries, uint32_t hunkbytes,
                 std::vector<uint8_t>& output, std::string& error);
bool decodeV5Map(const std::vector<uint8_t>& input, size_t count, uint32_t hunkbytes,
                 std::vector<V5MapEntry>& entries, std::string& error);
}

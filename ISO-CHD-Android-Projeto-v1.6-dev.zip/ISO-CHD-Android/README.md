# ISO ↔ CHD Converter v0.6-dev — CHD v5 parser foundation

## Status
This is **not yet a working ISO↔CHD converter**. Native C++ CHD v5 header decoding and DVD ISO size preflight have been implemented and tested on Linux. The Android UI deliberately keeps conversion disabled because the actual CHD v5 writer/reader is missing.

## Native CHD v5 implementation
`chd_v5.hpp` and `chd_v5.cpp` parse the 124-byte CHD v5 header (magic, version, compression tags, logical size, map and metadata offsets, hunk/unit sizes, SHA-1 fields) and perform basic structural checks. This is **not** full file verification. `validateDvdIso` checks nonempty 2048-byte-aligned input.

## Tests
Run from the repository root:

```sh
c++ -std=c++17 -Wall -Wextra -Werror app/src/main/cpp/chd_v5.cpp app/src/main/cpp/tests/header_test.cpp -o /tmp/chd_header_test
/tmp/chd_header_test
```

The above tests passed in the development environment. They are synthetic header/preflight tests, **not** real-world ISO/CHD round trips.

## Android build
GitHub Actions workflow is provided but Android APK compilation has **not** been executed here. JNI code now links the parser through CMake. `conversionSupported()` returns false and `convert()` returns -100 to avoid creating invalid output.

## Remaining work for a working encoder
Implement CHD v5 data hunks, compressed map encoding and codec support, SHA-1 generation, CHD reader, and validation against official MAME `chdman` with multiple PS2 DVD images. For reliable compatibility, integrating audited MAME CHD code (with its licensing and dependencies) is preferable to inventing the format.

## v0.7-dev — Uncompressed hunk block module
Added `chd_blocks.hpp/.cpp` with a bounded block-layout planner, big-endian 4-byte uncompressed map entries, padded hunk serialization, and reverse decoding. CMake includes the module. The block serializer reserves a zeroed 124-byte header area **as a placeholder**, not a valid CHD header.

### Run block tests
```sh
c++ -std=c++17 -Wall -Wextra -Werror app/src/main/cpp/chd_blocks.cpp app/src/main/cpp/tests/blocks_test.cpp -o /tmp/chd_blocks_test
/tmp/chd_blocks_test
```
Five synthetic round trips passed on Linux, including partial final hunks. Existing header tests also passed.

**Important:** `conversionSupported()` remains false. The generated block container is **not** a valid CHD file: header writing, hashes, metadata, compatibility validation against official CHDMAN, compressed maps/codecs, and Android build testing are pending. This version does not generate a usable APK or converter.

## v0.8-dev — v5 header writer and SHA-1
Added `chd_writer.hpp/.cpp`: portable SHA-1, full 124-byte v5 header serialization, raw ISO SHA-1, combined SHA-1 for images with no metadata, and verification of uncompressed map hunks. The writer uses the existing v0.7 uncompressed block format. This is a **candidate CHD v5 file**; compatibility with MAME's official CHDMAN is **not validated**. The writer is not yet connected to the Android JNI conversion API, and the UI deliberately keeps conversion disabled. No compressed hunks or metadata are supported.

Native regression test:
```sh
c++ -std=c++17 -Wall -Wextra -Werror app/src/main/cpp/chd_v5.cpp app/src/main/cpp/chd_blocks.cpp app/src/main/cpp/chd_writer.cpp app/src/main/cpp/tests/writer_test.cpp -o /tmp/chd_writer_test
/tmp/chd_writer_test
```
Four synthetic ISO round trips and deliberate corruption detection passed locally. No real PS2 game was tested. Android APK build was not performed.

## v0.9-dev — zlib / raw DEFLATE hunk codec
Implemented `chd_deflate.hpp/.cpp`: lossless per-hunk compression and decompression using zlib's raw DEFLATE streams, with input size limits, exact output-length validation, rejection of trailing compressed data, and truncation checks. The Android CMake target links against Android's `libz`.

Host regression tests:
```sh
g++ -std=c++17 -Wall -Wextra -Werror app/src/main/cpp/chd_deflate.cpp app/src/main/cpp/tests/deflate_test.cpp -lz -o /tmp/chd_deflate_test
/tmp/chd_deflate_test
```
Eight round trips passed for compressible and pseudorandom hunks, plus malformed input rejection. Previous header/block/writer tests also passed.

**Not yet implemented:** the compressed CHD v5 map (different from the 4-byte uncompressed map), hunk CRC-16 and codec selectors, full compressed-file writer/reader, interoperability testing against MAME chdman, Android JNI integration, and an installable APK. Do not label a raw DEFLATE stream as a CHD file or enable the conversion UI yet.

## v1.0-dev — compressed-hunk staging (NOT a CHD v5 compressed map)
Added `chd_compressed_stage.hpp/.cpp`, a tested intermediate payload builder that splits input into hunks, chooses raw DEFLATE or uncompressed payload per hunk, records byte offsets, stored/decoded lengths, and CRC-16/CCITT checksums, and reconstructs padded hunks with checksum verification. The index exists in memory; it is **not serialized as a valid CHD v5 compressed map**. CHD v5 requires a specific entropy-coded map, compression selectors, and its map-header CRC. This code does not claim CHD interoperability and remains disconnected from Android conversion.

Test: `g++ -std=c++17 -Wall -Wextra -Werror app/src/main/cpp/chd_deflate.cpp app/src/main/cpp/chd_compressed_stage.cpp app/src/main/cpp/tests/compressed_stage_test.cpp -lz -o /tmp/chd_stage_test && /tmp/chd_stage_test`

Five synthetic round trips and corruption checks passed locally. APK and official chdman interoperability are untested. The next milestone is implementing the **actual CHD v5 compressed map** against MAME's format specification and validating with chdman.

## v1.1-dev — compressed-map bitstream primitives (NOT a full compressed map)
Added `chd_map_bits.hpp/.cpp`: MSB-first variable-width bitstream reader/writer, CRC-16/CCITT-FALSE and integer bit-width calculation. Added regression tests including known CRC vector `123456789 -> 0x29b1`, cross-byte bit fields, malformed widths, and truncated input. Included source in Android CMake target. All prior host regression suites passed.

Test: `g++ -std=c++17 -Wall -Wextra -Werror app/src/main/cpp/chd_map_bits.cpp app/src/main/cpp/tests/map_bits_test.cpp -o /tmp/chd_map_bits_test && /tmp/chd_map_bits_test`

**Still missing:** CHD v5's canonical Huffman tree, symbol/RLE encoding, compressed map header/CRC verification against MAME, offset reconstruction, reference hunk types, official interoperability tests, Android build and functional APK. These primitives alone do not serialize a valid compressed CHD map. Conversion remains disabled.

## v1.2-dev — Canonical Huffman and experimental map symbol stream
Added `chd_map_huffman.hpp/.cpp` with canonical Huffman code assignment and bit-level encode/decode, bounded type-symbol RLE, and sequential stored-hunk offset reconstruction. The Huffman tree accepts externally supplied code lengths; it does not yet implement the MAME CHD v5 tree-length encoding. The RLE token grammar (literal 0..15, repeat 16 + 16-bit count) is **an internal test representation**, NOT the official CHD v5 map encoding. Reference hunks are deliberately rejected. These primitives cannot yet produce a CHD-compatible compressed map.

Run: `g++ -std=c++17 -Wall -Wextra -Werror app/src/main/cpp/chd_map_bits.cpp app/src/main/cpp/chd_map_huffman.cpp app/src/main/cpp/tests/map_huffman_test.cpp -o /tmp/chd_huff_test && /tmp/chd_huff_test`

Tested locally: canonical Huffman symbol roundtrip, repeated type expansion, offset reconstruction, invalid Huffman lengths, truncated repeat data, unsupported reference types. Official CHDMAN interoperability and Android APK build remain untested. Conversion remains disabled.

## v1.3-dev — CHD v5 compressed map serialization (stored hunks)
Added `chd_map_v5.hpp/.cpp` to the Android CMake target. It writes and reads the official 16-byte compressed-map header, 16-symbol Huffman tree encoded using MAME's tree RLE grammar, type symbols 0..4, per-hunk length and CRC fields, sequential offsets, and CRC-16 of reconstructed 12-byte raw map entries. The encoder uses a valid fixed 4-bit canonical Huffman tree and literal type symbols, rather than an optimized frequency-derived tree. The decoder also recognizes RLE type tokens 7/8, but does not support reference hunk types 5/6 or pseudo-reference types 9..13. No full compressed CHD writer is wired up; JNI conversion remains disabled. No official chdman interoperability or Android build test has been performed.

Host test:
```sh
g++ -std=c++17 -Wall -Wextra -Werror app/src/main/cpp/chd_map_bits.cpp app/src/main/cpp/chd_map_huffman.cpp app/src/main/cpp/chd_map_v5.cpp app/src/main/cpp/tests/map_v5_test.cpp -o /tmp/map_v5_test && /tmp/map_v5_test
```
Passed: 100-entry mixed stored-hunk map round trip and deliberate CRC corruption rejection. Source references: https://github.com/mamedev/mame/blob/master/src/lib/util/chd.cpp and https://github.com/mamedev/mame/blob/master/src/lib/util/huffman.cpp.

## v1.4-dev — experimental compressed CHD file writer
Added `chd_compressed_writer.hpp/.cpp` and `tests/compressed_writer_test.cpp`. The native writer combines a v5 header, raw DEFLATE hunks (CHD codec tag `zlib`), an encoded v5 compressed map, and SHA-1 fields. The native verifier decodes the map and hunks and checks CRC-16 and SHA-1. This is **experimental**: no independent official MAME chdman compatibility testing has been performed. No JNI conversion interface has been enabled; the Android UI still refuses conversion. No APK has been built or tested.

Host test:
```sh
cd app/src/main/cpp
g++ -std=c++17 -Wall -Wextra -Werror chd_v5.cpp chd_map_bits.cpp chd_map_huffman.cpp chd_map_v5.cpp chd_deflate.cpp chd_compressed_writer.cpp tests/compressed_writer_test.cpp -lz -o /tmp/chd_v14_test
/tmp/chd_v14_test
```
Four synthetic images passed writer + verifier self-tests and deliberate payload corruption detection. **These tests are not independent interoperability validation.**

## v1.5-dev — integração JNI experimental
- `NativeChd.convert` agora chama o gerador ISO→CHD ou o extrator CHD→ISO.
- `NativeChd.verify` executa a verificação interna de CRC e SHA-1.
- Extrator suporta somente o subconjunto CHD v5 produzido pelo projeto: DVD 2048 bytes/setor, zlib/raw, sem metadados/referências. CHDs genéricos não são suportados.
- Testes locais Linux: `tests/extract_test.cpp` com cinco tamanhos sintéticos; biblioteca JNI compilada com cabeçalhos Java locais.
- **Ainda não houve build APK/NDK nem teste em Android.** O cancelamento da UI não interrompe a chamada C++ em andamento: somente o processamento entre arquivos. Há cópias temporárias de entrada e saída no armazenamento interno; ISOs grandes podem exceder o espaço livre.
- Para executar o teste: `g++ -std=c++17 -O2 -Wall -Wextra -Werror app/src/main/cpp/tests/extract_test.cpp app/src/main/cpp/chd_{v5,blocks,writer,deflate,compressed_stage,map_bits,map_huffman,map_v5,compressed_writer}.cpp -lz -o /tmp/extract_test && /tmp/extract_test`.


## v1.6-dev — build ARM64 reproduzível (não testado em Android)
- Fixado NDK 27.2.12479018, CMake 3.22.1 e ABI arm64-v8a no Gradle.
- GitHub Actions agora executa dois testes nativos de regressão antes de compilar e publica o APK de depuração.
- Corrigidos textos desatualizados da interface, incluindo aviso de cancelamento que não interrompe uma chamada C++ já iniciada.
- A compilação real do APK e a execução no Android **não foram verificadas neste ambiente**.
- O app ainda usa arquivos temporários internos de entrada e saída, podendo exigir muito espaço livre.
- Suporte CHD→ISO limitado ao subconjunto zlib/raw de DVD produzido por este projeto.

Para gerar APK: publique o conteúdo deste diretório na raiz de um repositório GitHub, execute Actions > Android ARM64 APK and native tests > Run workflow e baixe o artefato.

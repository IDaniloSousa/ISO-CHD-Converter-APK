#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/../app/src/main/cpp"
mkdir -p /tmp/isochd-native-tests
CXX="${CXX:-g++}"
flags=(-std=c++17 -O2 -Wall -Wextra -Werror)
"$CXX" "${flags[@]}" chd_v5.cpp chd_map_bits.cpp chd_map_huffman.cpp chd_map_v5.cpp chd_deflate.cpp chd_compressed_writer.cpp tests/compressed_writer_test.cpp -lz -o /tmp/isochd-native-tests/writer
/tmp/isochd-native-tests/writer
"$CXX" "${flags[@]}" tests/extract_test.cpp chd_v5.cpp chd_blocks.cpp chd_writer.cpp chd_deflate.cpp chd_compressed_stage.cpp chd_map_bits.cpp chd_map_huffman.cpp chd_map_v5.cpp chd_compressed_writer.cpp -lz -o /tmp/isochd-native-tests/extract
/tmp/isochd-native-tests/extract
